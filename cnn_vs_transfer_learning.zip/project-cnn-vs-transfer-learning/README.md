# CNN from Scratch vs Transfer Learning

## Identitas
* **Nama:** Muhammad Aditya Azka Azkia
* **Mata Kuliah:** Deep Learning / Pembelajaran Mesin

## Struktur Folder
* dataset/
* notebook/
* report/